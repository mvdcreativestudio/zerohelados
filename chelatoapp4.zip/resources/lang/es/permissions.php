<?php

return [
  'access_dashboard' => 'Acceder al panel de control',
  'access_raw-materials' => 'Acceder a materias primas',
  'access_stock' => 'Acceder a stock',
  'access_accounting' => 'Acceder a contabilidad',
  'access_ecommerce' => 'Acceder a comercio electrónico',
  'access_omnichannel' => 'Acceder a omnicanal',
  'access_datacenter' => 'Acceder a centro de datos',
  'access_crm' => 'Acceder a CRM',
  'access_stores' => 'Acceder a tiendas',
  'access_roles' => 'Acceder a roles',
  'view_all_raw-materials' => 'Ver todas las materias primas',
  'access_suppliers' => 'Acceder a proveedores',
  'view_all_suppliers' => 'Ver todos los proveedores',
  'access_supplier-orders' => 'Acceder a órdenes de compra',
  'view_all_supplier-orders' => 'Ver todas las órdenes de compra',
];
